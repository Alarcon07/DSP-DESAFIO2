import * as React from 'react';
import { View, Text, Image, ScrollView, TextInput, Button, Alert, StyleSheet, TouchableOpacity, Modal, Pressable, ImageBackground } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as Notifications from 'expo-notifications';
import { Calendar } from 'react-native-calendars';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const Drawer = createDrawerNavigator();

export default function App() {
  React.useEffect(() => {
    const pedirPermisos = async () => {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permiso denegado', 'No se podrán enviar recordatorios.');
      }
    };
    pedirPermisos();
  }, []);

  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Inicio">
        <Drawer.Screen name="Inicio" component={HomeScreen} />
        <Drawer.Screen name="Acciones Verdes" component={GreenActionsScreen} />
        <Drawer.Screen name="Mis Actividades" component={ActivitiesScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

function HomeScreen() {
  return (
    <ImageBackground
      source={{ uri: 'https://i.pinimg.com/736x/cd/ba/e0/cdbae06de9c6dbdf10812f023645c141.jpg' }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <Text style={styles.title}>🌱 Bienvenido a EcoVida App</Text>
        <Text style={styles.subtitle}>Promoviendo un futuro más verde 🌍</Text>
      </View>
    </ImageBackground>
  );
}

function GreenActionsScreen() {
  const acciones = [
    {
      nombre: 'Plantar árboles',
      descripcion: 'Ayuda a mejorar el aire y combatir el cambio climático.',
      imagen: 'https://i.pinimg.com/736x/10/cb/9a/10cb9a66c773fb16e22e87fdf29d0de8.jpg',
    },
    {
      nombre: 'Reciclar',
      descripcion: 'Reduce residuos y ahorra energía.',
      imagen: 'https://i.pinimg.com/736x/07/f9/8a/07f98ae612dfb6c933c99bc83b05c968.jpg',
    },
    {
      nombre: 'Ahorrar agua',
      descripcion: 'Preserva este recurso vital para todos.',
      imagen: 'https://i.pinimg.com/736x/56/62/cb/5662cbed3b282badf4305e69ec50bd0e.jpg',
    },
    {
      nombre: 'Usar bicicleta',
      descripcion: 'Reduce la contaminación del aire.',
      imagen: 'https://i.pinimg.com/736x/f3/83/cb/f383cbac8371d17a3df7168c457fe302.jpg',
    },
  ];

  return (
    <ImageBackground
      source={{ uri: 'https://i.pinimg.com/736x/3c/3a/c8/3c3ac844d7c9ed632f5b6c95b5517d60.jpg' }}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView contentContainerStyle={styles.actionsContainer}>
        {acciones.map((accion, index) => (
          <View key={index} style={styles.card}>
            <Image source={{ uri: accion.imagen }} style={styles.cardImage} />
            <Text style={styles.cardTitle}>{accion.nombre}</Text>
            <Text style={styles.cardDescription}>{accion.descripcion}</Text>
          </View>
        ))}
      </ScrollView>
    </ImageBackground>
  );
}

function ActivitiesScreen() {
  const [nombre, setNombre] = React.useState('');
  const [fecha, setFecha] = React.useState(new Date());
  const [mostrarPicker, setMostrarPicker] = React.useState(false);
  const [lugar, setLugar] = React.useState('');
  const [tipo, setTipo] = React.useState('');
  const [actividades, setActividades] = React.useState({});
  const [fechaSeleccionada, setFechaSeleccionada] = React.useState('');
  const [modalVisible, setModalVisible] = React.useState(false);
  const [actividadesDelDia, setActividadesDelDia] = React.useState([]);

  React.useEffect(() => {
    cargarActividades();
  }, []);

  const guardarActividad = async () => {
    if (!nombre || !fecha || !lugar || !tipo) {
      Alert.alert('Error', 'Por favor, llena todos los campos.');
      return;
    }

    const fechaLocal = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
    const fechaISO = fechaLocal.toISOString().split('T')[0];
    const nueva = {
      nombre: nombre.trim(),
      fecha: fechaISO,
      lugar: lugar.trim(),
      tipo: tipo.trim(),
    };

    const nuevasActividades = { ...actividades };
    if (!nuevasActividades[fechaISO]) {
      nuevasActividades[fechaISO] = [];
    }

    const yaExiste = nuevasActividades[fechaISO].some(
      (a) => a.nombre === nueva.nombre && a.lugar === nueva.lugar
    );

    if (yaExiste) {
      Alert.alert('Duplicado', 'Esta actividad ya fue registrada.');
      return;
    }

    nuevasActividades[fechaISO].push(nueva);
    setActividades(nuevasActividades);
    await AsyncStorage.setItem('actividades', JSON.stringify(nuevasActividades));

    await Notifications.scheduleNotificationAsync({
      content: {
        title: '🌿 Recordatorio Ecológico',
        body: `Hoy es el día para: ${nueva.nombre} en ${nueva.lugar}`,
      },
      trigger: new Date(fecha),
    });

    limpiarFormulario();
  };

  const limpiarFormulario = () => {
    setNombre('');
    setFecha(new Date());
    setLugar('');
    setTipo('');
  };

  const cargarActividades = async () => {
    const datos = await AsyncStorage.getItem('actividades');
    if (datos) setActividades(JSON.parse(datos));
  };

  const eliminarActividad = async (fecha, index) => {
    const copia = { ...actividades };
    copia[fecha].splice(index, 1);
    if (copia[fecha].length === 0) delete copia[fecha];
    setActividades(copia);
    await AsyncStorage.setItem('actividades', JSON.stringify(copia));
    setModalVisible(false);
  };

  const abrirModal = (date) => {
    setFechaSeleccionada(date.dateString);
    setActividadesDelDia(actividades[date.dateString] || []);
    setModalVisible(true);
  };

  const getMarkedDates = () => {
    const marcado = {};
    for (let fecha in actividades) {
      if (actividades[fecha].length > 0) {
        marcado[fecha] = { marked: true, dotColor: '#2e7d32' };
      }
    }
    return marcado;
  };

  return (
    <ImageBackground
      source={{ uri: 'https://i.pinimg.com/736x/3c/3a/c8/3c3ac844d7c9ed632f5b6c95b5517d60.jpg' }}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView style={{ padding: 20 }}>
        <Text style={styles.subtitle}>📋 Agregar Actividad Ecológica</Text>
        <TextInput placeholder="🌿 Nombre" value={nombre} onChangeText={setNombre} style={styles.input} />
        <TouchableOpacity onPress={() => setMostrarPicker(true)}>
          <Text style={styles.input}>📅 Fecha: {fecha.toLocaleDateString('es-ES')}</Text>
        </TouchableOpacity>
        {mostrarPicker && (
          <DateTimePicker
            value={fecha}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              const currentDate = selectedDate || fecha;
              setMostrarPicker(false);
              setFecha(currentDate);
            }}
          />
        )}
        <TextInput placeholder="📍 Lugar" value={lugar} onChangeText={setLugar} style={styles.input} />
        <Text style={{ marginTop: 10 }}>🧑‍🤝‍🧑 Tipo:</Text>
        <View style={{ borderWidth: 1, borderRadius: 5, marginBottom: 15 }}>
          <Picker selectedValue={tipo} onValueChange={(itemValue) => setTipo(itemValue)}>
            <Picker.Item label="Selecciona un tipo..." value="" />
            <Picker.Item label="Con fumadores 🚬" value="con fumadores" />
            <Picker.Item label="Sin fumadores 🚭" value="sin fumadores" />
          </Picker>
        </View>
        <Button title="✅ Agregar Actividad" onPress={guardarActividad} />

        <Text style={styles.subtitle}>🗓️ Calendario de Actividades</Text>
        <Calendar
          onDayPress={abrirModal}
          markedDates={getMarkedDates()}
          theme={{ selectedDayBackgroundColor: '#66bb6a', todayTextColor: '#388e3c' }}
        />

        <Modal visible={modalVisible} animationType="slide" transparent={true}>
          <View style={styles.modalView}>
            <Text style={styles.subtitle}>📅 Actividades del {fechaSeleccionada}</Text>
            {actividadesDelDia.length === 0 ? (
              <Text style={{ fontStyle: 'italic' }}>No hay actividades registradas.</Text>
            ) : (
              actividadesDelDia.map((item, index) => (
                <View key={index} style={styles.activityItem}>
                  <Text><Icon name="leaf" size={16} color="#2e7d32" /> {item.nombre}</Text>
                  <Text><Icon name="map-marker" size={16} /> {item.lugar}</Text>
                  <Text><Icon name="account" size={16} /> {item.tipo}</Text>
                  <Button title="🗑️ Eliminar" color="#c62828" onPress={() => eliminarActividad(fechaSeleccionada, index)} />
                </View>
              ))
            )}
            <Pressable style={styles.closeButton} onPress={() => setModalVisible(false)}>
              <Text style={{ color: '#fff' }}>Cerrar</Text>
            </Pressable>
          </View>
        </Modal>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    backgroundColor: 'rgba(255,255,255,0.85)',
    padding: 30,
    alignItems: 'center',
  },
  container: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 26,
    marginBottom: 10,
    fontWeight: 'bold',
    color: '#2e7d32',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    marginVertical: 10,
    fontWeight: 'bold',
    color: '#388e3c',
    textAlign: 'center',
  },
  actionsContainer: {
    padding: 15,
    alignItems: 'center',
  },
  card: {
    backgroundColor: '#e8f5e9',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    width: '90%',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
  },
  cardImage: {
    height: 150,
    borderRadius: 10,
    marginBottom: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2e7d32',
  },
  cardDescription: {
    fontSize: 14,
    color: '#4caf50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#c8e6c9',
    padding: 10,
    marginVertical: 8,
    borderRadius: 5,
    backgroundColor: '#f1f8e9',
  },
  activityItem: {
    backgroundColor: '#f1f8e9',
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
  },
  modalView: {
    backgroundColor: 'white',
    margin: 20,
    marginTop: 100,
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  closeButton: {
    backgroundColor: '#2e7d32',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    alignSelf: 'flex-end',
  },
});
